#ifndef MODULES_DRIVERS_GNSS_YUANSHAN_MESSAGES_H_
#define MODULES_DRIVERS_GNSS_YUANSHAN_MESSAGES_H_

#include <stdint.h>
#include "modules/drivers/gnss/proto/config.pb.h"

namespace apollo {
namespace drivers {
namespace gnss {
namespace yuanshan {

enum  MessageId : uint8_t 
{
  CMD_GPGSV = 1,
  CMD_BDGSV = 2,
  CMD_GNGGA = 3,
  CMD_GNGSA = 4,
  CMD_GNRMC = 5,
};

enum class SolutionType : uint32_t 
{
  NONE      = 0,//无效解
  SINGLE    = 1,//单点解
  PSRDIFF   = 2,//伪距差分解
  RT2       = 4,//固定解
  RTK_FLOAT = 5,//浮点解
};

/*===================================================*/

}  // namespace yuanshan
}  // namespace gnss
}  // namespace drivers
}  // namespace apollo

#endif  // MODULES_DRIVERS_GNSS_YUANSHAN_MESSAGES_H_