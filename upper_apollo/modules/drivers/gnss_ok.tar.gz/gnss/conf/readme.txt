first check imutoantoffset saved in device, method below:
screen /dev/ttyUSB2

log imutoantoffsets

