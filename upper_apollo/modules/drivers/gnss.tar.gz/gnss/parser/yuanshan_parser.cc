#include <cmath>
#include <iostream>
#include <limits>
#include <memory>

#include <vector>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#include "ros/include/ros/ros.h"

#include "modules/common/log.h"
#include "modules/drivers/gnss/parser/yuanshan_messages.h"
#include "modules/drivers/gnss/parser/parser.h"
#include "modules/drivers/gnss/parser/rtcm_decode.h"
#include "modules/drivers/gnss/proto/gnss.pb.h"
#include "modules/drivers/gnss/proto/gnss_best_pose.pb.h"
#include "modules/drivers/gnss/proto/gnss_raw_observation.pb.h"
#include "modules/drivers/gnss/proto/heading.pb.h"
#include "modules/drivers/gnss/proto/imu.pb.h"
#include "modules/drivers/gnss/proto/ins.pb.h"
#include "modules/drivers/gnss/util/time_conversion.h"
#include "modules/drivers/gnss/parser/rtcm_decode.h"

#include <iomanip>

using namespace std;

namespace apollo {
namespace drivers {
namespace gnss {
// Anonymous namespace that contains helper constants and functions.
namespace {

    constexpr size_t BUFFER_SIZE = 256;
    constexpr float FLOAT_NAN = std::numeric_limits<float>::quiet_NaN();
    constexpr double DEG_TO_RAD = M_PI / 180.0;
    // enum _fixtype 
    // { 
    //     FIX_TYPE_NONE, 
    //     FIX_TYPE_GPS, 
    //     FIX_TYPE_DIFF 
    // };

    enum _fix 
    { 
        FIX_NONE = 1, 
        FIX_2D, 
        FIX_3D 
    };
    enum _op_mode 
    { 
        MODE_MANUAL, 
        MODE_AUTOMATIC 
    };

    struct satellite
    {
        uint8_t prn;
        int16_t elevation;
        int16_t azimuth;
        uint8_t snr; //signal to noise ratio
    };

    struct _datetime
    {
        uint8_t day, month, year;
        uint8_t hours, minutes, seconds;
        uint16_t millis;
        bool valid; //1 = yes, 0 = no
    };

    uint8_t parse_hex(char c)
    {
        if (c < '0')
            return 0;
        if (c <= '9')
            return c - '0';
        if (c < 'A')
            return 0;
        if (c <= 'F')
            return (c - 'A')+10;
        return 0;
    }
        constexpr double azimuth_deg_to_yaw_rad(double azimuth)
        {
        return (90.0 - azimuth) * DEG_TO_RAD;
        }

}// namespace

class YuanShanParser : public Parser {
public:
    YuanShanParser();
    explicit YuanShanParser(const config::Config& config);

    virtual MessageType GetMessage(MessagePtr* message_ptr);
//add ycy start 
public:
    class Tokeniser
    {
    public:
        Tokeniser(char* str, char token);
        bool next(char* out, int len);

    private:
        char* str;
        char token;
    };


    float latitude, longitude, altitude, vert_speed;
    int latlng_age, alt_age;

     //these units are in hundredths
    //so a speed of 5260 means 52.60km/h
    uint16_t speed, course, knots;
    int speed_age, course_age, knots_age;

    int fixtype_age;
    _fix fix;
    int fix_age;

    float pdop, hdop, vdop; //positional, horizontal and vertical dilution of precision
    int dop_age;

    int8_t sats_in_use;
    int8_t sats_in_view;

    satellite sats[12];
    int sats_age;

    _datetime datetime;
    int time_age, date_age;

    _op_mode op_mode;

private:

    bool check_checksum();

    char buf[120];

    void readGN_gga();//GPS定位信息
    void readGP_gga();

    void read_gsa();//当前卫星信息
    void read_gsv();//GPGSV：可见卫星信息
    void readNG_rmc();//GPRMC：推荐最小定位信息
    void read_vtg();//地面速度信息


    raw_t raw_;  // used for observation data
    Parser::MessageType PrepareMessage(MessagePtr* message_ptr);

//add ycy end
private:
    bool verify_checksum();

    Parser::MessageType prepare_message(MessagePtr& message_ptr);

    // The handle_xxx functions return whether a message is ready.
    // bool handle_esf_raw(const ublox::EsfRaw* raw, size_t data_size);
    // bool handle_esf_ins(const ublox::EsfIns* ins);


    double _gps_seconds_base = -1.0;
    double _gyro_scale = 0.0;
    double _accel_scale = 0.0;

    float _imu_measurement_span = 0.0;
    int _imu_frame_mapping = 5;
    double _imu_measurement_time_previous = -1.0;


    std::vector<char> buffer_;
    std::string line;
    //std::vector<uint8_t> buffer_;

    size_t total_length_ = 0;

    ::apollo::drivers::gnss::Gnss gnss_;
    ::apollo::drivers::gnss::Imu imu_;
    ::apollo::drivers::gnss::Ins ins_;
};

/*==============================================================*/
//初始化类Tokeniser
YuanShanParser::Tokeniser::Tokeniser(char* _str, char _token)
{
    str = _str;
    token = _token;
}
bool YuanShanParser::Tokeniser::next(char* out, int len)
{
    uint8_t count = 0;

    if(str[0] == 0)
        return false;

    while(true)
    {
        if(str[count] == '\0')
        {
            out[count] = '\0';
            str = &str[count];
            return true;
        }

        if(str[count] == token)
        {
            out[count] = '\0';
            count++;
            str = &str[count];
            return true;
        }

        if(count < len)
            out[count] = str[count];

        count++;
    }
    return false;
}
/*==============================================================*/

/**********************************************************
 * @模块入口 构造类
 * 
 **********************************************************/
Parser* Parser::create_yuanshan(const config::Config& config)
{
    return new YuanShanParser();
    //return new YuanShanParser(config);
}
YuanShanParser::YuanShanParser() 
{
  buffer_.reserve(BUFFER_SIZE);
  ins_.mutable_position_covariance()->Resize(9, FLOAT_NAN);
  ins_.mutable_euler_angles_covariance()->Resize(9, FLOAT_NAN);
  ins_.mutable_linear_velocity_covariance()->Resize(9, FLOAT_NAN);

  if (1 != init_raw(&raw_)) 
  {
    AFATAL << "memory allocation error for observation data structure.";
  }
}

YuanShanParser::YuanShanParser(const config::Config& config) 
{
  buffer_.reserve(BUFFER_SIZE);
  ins_.mutable_position_covariance()->Resize(9, FLOAT_NAN);
  ins_.mutable_euler_angles_covariance()->Resize(9, FLOAT_NAN);
  ins_.mutable_linear_velocity_covariance()->Resize(9, FLOAT_NAN);


  if (1 != init_raw(&raw_)) 
  {
    AFATAL << "memory allocation error for observation data structure.";
  }
}
/***********************************************************
 * 
***********************************************************/

Parser::MessageType YuanShanParser::GetMessage(MessagePtr* message_ptr) 
{
  if (data_ == nullptr) 
  {
    return MessageType::NONE;
  } 


    // *message_ptr = &ins_;

  //  *message_ptr = &gnss_;

   // return MessageType::GNSS;

  #if 1
//jiex
  /* data example:
$GNGGA,055136.00,3023.81376766,N,10404.32368675,E,7,10,1.4,449.1208,M,0.0000,M,00,0000*41
$GNRMC,055136.00,A,3023.81376766,N,10404.32368675,E,0.035,71.4,020818,0.0,E,A*1F
  */
  while (data_ < data_end_) 
  {
      buffer_.push_back(*data_);
      line+=*data_;
      data_++;
      total_length_++;

    #if  1
    if(*data_ == '\n') //linefeed
    {
        strcpy(buf, line.c_str()); 
        // AINFO<<line;
        MessageType type = PrepareMessage(message_ptr);
        buffer_.clear();
        line.clear();
        memset(buf, '\0', 120);
        total_length_ = 0;
        if (type != MessageType::NONE) 
        {
            return type;
        }
    }

    if(buffer_.size() >= 120) //avoid a buffer overrun
    {
        buffer_.clear();
        line.clear();
        memset(buf, '\0', 120);
        total_length_ = 0;
    }

    #endif
  }
 
  return MessageType::NONE;
   #endif
}

Parser::MessageType YuanShanParser::PrepareMessage(MessagePtr* message_ptr) 
{

       // *message_ptr = &gnss_;
       // return MessageType::GNSS;

    //otherwise, what sort of message is it
    if(strncmp(&buf[1], "$GNRMC", 6) == 0)
    {

        if(!check_checksum()) //if checksum is bad
        {
            AERROR << "check_checksum check failed.";
            return MessageType::NONE; //return
        }
        readNG_rmc();
        // if (HandleCorrImuData(reinterpret_cast<novatel::CorrImuData*>(message))) 
        // {
          *message_ptr = &ins_;
        //     return MessageType::INS;
        // }
        return MessageType::INS;
    }
    if(strncmp(&buf[1], "$GNGGA", 6) == 0)
    {
        if(!check_checksum()) //if checksum is bad
        {
            AERROR << "check_checksum check failed.";
            return MessageType::NONE; //return
        }
        readGN_gga();//全球定位数据）
        *message_ptr = &ins_;
        return MessageType::INS;
    }


    #if 0
    if(strncmp(&buf[1], "$GPGGA", 6) == 0)
    {
        // readGP_gga();
        // if (HandleCorrImuData(reinterpret_cast<novatel::CorrImuData*>(message))) 
        // {
        //     *message_ptr = &ins_;
        //     return MessageType::INS;
        // }
        return MessageType::GNSS;
    }

    if(strncmp(&buf[1], "$GNGGA", 6) == 0)
    {
        if(!check_checksum()) //if checksum is bad
        {
            AERROR << "check_checksum check failed.";
            return MessageType::NONE; //return
        }
      //  readGN_gga();//全球定位数据）
        return MessageType::GNSS;
    }
#endif
#if 0
    if(strncmp(&buf[1], "$GNVTG", 6) == 0)
    {
        read_vtg();//地面速度信息
    }

    if(strncmp(&buf[1], "$GNGSA", 6) == 0)
    {
        read_gsa();//当前位置信息 shis
    }

    if(strncmp(&buf[1], "$GPGSV", 6) == 0)
    {
        read_gsv();//卫星状态信息）
    }
    return true;

#endif
  return MessageType::NONE;
}

// GNGGA 
// UTC时间,纬度,纬半球,经度,经半球,定位质量标,卫星数量,水平精确度,天、地水准高度，差分GPS数据等, *, 校验和, 回车、换行
void YuanShanParser::readGN_gga()
{
    int counter = 0;
    char token[20];
    Tokeniser tok(buf, ',');

    while(tok.next(token, 20))
    {
        switch(counter)
        {
        case 1: //time
        {
            float time = atof(token);
            int hms = int(time);

            datetime.millis = time - hms;
            datetime.seconds = fmod(hms, 100);
            hms /= 100;
            datetime.minutes = fmod(hms, 100);
            hms /= 100;
            datetime.hours = hms;
            // time_age = millis();
        }
        break;
        case 2: //latitude
        {
            float llat = atof(token);
            int ilat = llat/100;
            double mins = fmod(llat, 100);
            latitude = ilat + (mins/60);
        }
        break;
        case 3: //north/south
        {
            if(token[0] == 'S')
            {
                latitude = -latitude;
                AINFO<<"GGA 南纬度"<<latitude;
            }
            else
            {
                AINFO<<"GGA 北纬度"<<latitude;
            }
            ins_.mutable_position()->set_lat(latitude);
            gnss_.mutable_position()->set_lat(latitude);
        }
        break;
        case 4: //longitude
        {
            float llong = atof(token);
            int ilat = llong/100;
            double mins = fmod(llong, 100);
            longitude = ilat + (mins/60);
        }
        break;
        case 5: //east/west
        {
            if(token[0] == 'W')
            {
                longitude = -longitude;
                AINFO<<"GGA 西经度"<<longitude;
            }
            else
            {
                AINFO<<"GGA 西经度"<<longitude;
            }
            ins_.mutable_position()->set_lon(longitude);
            gnss_.mutable_position()->set_lon(longitude);

        }
        break;
        case 6:
        {
            //gps 状态 
           uint32_t fixtype = (atoi(token));
            //  fixtype = atoi(token);
            if(fixtype==0)
            {
                AINFO<<"GGA 定位质量标定位无效 NONE INVALID";
                // ins_.set_type(apollo::drivers::gnss::Ins::INVALID);
                gnss_.set_type(apollo::drivers::gnss::Gnss::INVALID);
                ins_.set_type(apollo::drivers::gnss::Ins::INVALID);
            }
            else if(fixtype==1)
            {
                AINFO<<"GGA 定位质量标定位有效 GPS CONVERGING";
                // ins_.set_type(apollo::drivers::gnss::Ins::CONVERGING);
                gnss_.set_type(apollo::drivers::gnss::Gnss::SINGLE);
                ins_.set_type(apollo::drivers::gnss::Ins::CONVERGING);
            }
            else if(fixtype==2)
            {
                AINFO<<"GGA 定位质量标定位有效 DIFF PSRDIFF ";
                ins_.set_type(apollo::drivers::gnss::Ins::GOOD);
                gnss_.set_type(apollo::drivers::gnss::Gnss::PSRDIFF);
                // ins_.set_type(apollo::drivers::gnss::Ins::CONVERGING);
            }
            else if(fixtype==4)//固定解
            {
                gnss_.set_type(apollo::drivers::gnss::Gnss::RTK_INTEGER);
                ins_.set_type(apollo::drivers::gnss::Ins::GOOD);
            }
            else if(fixtype==5)
            {
                gnss_.set_type(apollo::drivers::gnss::Gnss::RTK_FLOAT);
                ins_.set_type(apollo::drivers::gnss::Ins::CONVERGING);
            }
            else
            {
                 ins_.set_type(apollo::drivers::gnss::Ins::INVALID);
            }
        }
        break;
        case 7:
        {
            sats_in_use = atoi(token);
            AINFO<<"使用卫星数量，从00到12="<<sats_in_use;
            gnss_.set_num_sats(sats_in_use);
             
        }
        break;
        case 8:
        {
            hdop = atoi(token);
            AINFO<<"水平精确度，0.5到99.9。="<<hdop;
            
        }
        break;
        case 9:
        {
           float new_alt = atof(token);
           gnss_.mutable_position()->set_height(new_alt);
           AINFO<<"天、地水准高度="<<new_alt;
           ins_.mutable_position()->set_height(new_alt);
           ins_.mutable_header()->set_timestamp_sec(ros::Time::now().toSec());
        //    vert_speed = (new_alt - altitude)/((millis()-alt_age)/1000.0);
        //    altitude = atof(token);
            //alt_age = millis();
        }
        break;
        }
        counter++;
    }
}


// GNGGA 
// UTC时间,纬度,纬半球,经度,经半球,定位质量标,卫星数量,水平精确度,天、地水准高度，差分GPS数据等, *, 校验和, 回车、换行
void YuanShanParser::readGP_gga()
{
    int counter = 0;
    char token[20];
    Tokeniser tok(buf, ',');

    while(tok.next(token, 20))
    {
        switch(counter)
        {
        case 1: //time
        {
            float time = atof(token);
            int hms = int(time);

            datetime.millis = time - hms;
            datetime.seconds = fmod(hms, 100);
            hms /= 100;
            datetime.minutes = fmod(hms, 100);
            hms /= 100;
            datetime.hours = hms;
            // time_age = millis();
        }
        break;
        case 2: //latitude
        {
            float llat = atof(token);
            int ilat = llat/100;
            double mins = fmod(llat, 100);
            latitude = ilat + (mins/60);
        }
        break;
        case 3: //north/south
        {
            if(token[0] == 'S')
            {
                latitude = -latitude;
                AINFO<<"GGA 南纬度<<latitude";
            }
            else
            {
                AINFO<<"GGA 北纬度<<latitude";
            }
            ins_.mutable_position()->set_lat(latitude);
            gnss_.mutable_position()->set_lat(latitude);
        }
        break;
        case 4: //longitude
        {
            float llong = atof(token);
            int ilat = llong/100;
            double mins = fmod(llong, 100);
            longitude = ilat + (mins/60);
        }
        break;
        case 5: //east/west
        {
            if(token[0] == 'W')
            {
                longitude = -longitude;
                AINFO<<"GGA 西经度<<longitude";
            }
            else
            {
                AINFO<<"GGA 西经度<<longitude";
            }
            ins_.mutable_position()->set_lon(longitude);
            gnss_.mutable_position()->set_lon(longitude);

        }
        break;
        case 6:
        {
            //gps 状态 
            // GPS状态， 0初始化， 1单点定位， 2码差分， 3无效PPS， 4固定解， 5浮点解， 6正在估算 7，人工输入固定值， 8模拟模式， 9WAAS差分
           uint32_t fixtype = (atoi(token));
            //  fixtype = atoi(token);
            if(fixtype==0)
            {
                AINFO<<"GGA 定位质量标定位无效 NONE INVALID";
                // ins_.set_type(apollo::drivers::gnss::Ins::INVALID);
                gnss_.set_type(apollo::drivers::gnss::Gnss::INVALID);
            }
            else if(fixtype==1)
            {
                AINFO<<"GGA 定位质量标定位有效 GPS CONVERGING";
                // ins_.set_type(apollo::drivers::gnss::Ins::CONVERGING);
                gnss_.set_type(apollo::drivers::gnss::Gnss::SINGLE);
            }
            else if(fixtype==2)
            {
                AINFO<<"GGA 定位质量标定位有效 DIFF PSRDIFF ";
                // ins_.set_type(apollo::drivers::gnss::Ins::GOOD);
                gnss_.set_type(apollo::drivers::gnss::Gnss::PSRDIFF);
            }
            else if(fixtype==4)//固定解
            {
                gnss_.set_type(apollo::drivers::gnss::Gnss::RTK_INTEGER);
            }
            else if(fixtype==5)
            {
                gnss_.set_type(apollo::drivers::gnss::Gnss::RTK_FLOAT);
            }
        }
        break;
        case 7:
        {
            sats_in_use = atoi(token);
            AINFO<<"使用卫星数量，从00到12="<<sats_in_use;
            gnss_.set_num_sats(sats_in_use);
             
        }
        break;
        case 8:
        {
            hdop = atoi(token);
            AINFO<<"水平精确度，0.5到99.9。="<<hdop;
            
        }
        break;
        case 9:
        {
            // 海拔高度，-9999.9到9999.9米 M 指单位米
           float new_alt = atof(token);
           gnss_.mutable_position()->set_height(new_alt);
           AINFO<<"天、地水准高度="<<new_alt;
        //    vert_speed = (new_alt - altitude)/((millis()-alt_age)/1000.0);
        //    altitude = atof(token);
            //alt_age = millis();
        }
        break;
        }
        counter++;
    }
}

void YuanShanParser::read_gsa()
{
    int counter = 0;
    char token[20];
    Tokeniser tok(buf, ',');

    while(tok.next(token, 20))
    {
        switch(counter)
        {
        case 1: //operating mode
        {
            if(token[0] == 'A')
                op_mode = MODE_AUTOMATIC;
            if(token[0] == 'M')
                op_mode = MODE_MANUAL;
        }
        break;
        case 2:
        {
            fix = _fix(atoi(token));
            // fix_age = millis();
        }
        break;
        case 14:
        {
            pdop = atof(token);
        }
        break;
        case 15:
        {
            hdop = atof(token);
        }
        break;
        case 16:
        {
            vdop = atof(token);
            // dop_age = millis();
        }
        break;
        }
        counter++;
    }
}


void YuanShanParser::read_gsv()
{
    char token[20];
    Tokeniser tok(buf, ',');

    tok.next(token, 20);
    tok.next(token, 20);

    tok.next(token, 20);
    int mn = atoi(token); //msg number

    tok.next(token, 20);
    sats_in_view = atoi(token); //number of sats

    int8_t j = (mn-1) * 4;
    int8_t i;

    for(i = 0; i <= 3; i++)
    {
        tok.next(token, 20);
        sats[j+i].prn = atoi(token);

        tok.next(token, 20);
        sats[j+i].elevation = atoi(token);

        tok.next(token, 20);
        sats[j+i].azimuth = atoi(token);

        tok.next(token, 20);
        sats[j+i].snr = atoi(token);
    }
    // sats_age = millis();
}

//[ $GNRMC,055136.00,A,3023.81376766,N,10404.32368675,E,0.035,71.4,020818,0.0,E,A*1F ]
// 字段 1：UTC时间，hhmmss.sss格式
// 字段 2：状态，A=定位，V=未定位
// 字段 3：纬度ddmm.mmmm，度分格式（前导位数不足则补0）
// 字段 4：纬度N（北纬）或S（南纬）
// 字段 5：经度dddmm.mmmm，度分格式（前导位数不足则补0）
// 字段 6：经度E（东经）或W（西经）
// 字段 7：速度，节，Knots（一节也是1.852千米／小时）
// 字段 8：方位角，度（二维方向指向，相当于二维罗盘）
// 字段 9：UTC日期，DDMMYY格式
// 字段10：磁偏角，（000 - 180）度（前导位数不足则补0）
// 字段11：磁偏角方向，E=东，W=西
// 字段12：模式，A=自动，D=差分，E=估测，N=数据无效（3.0协议内容）
// 字段13：校验值

void YuanShanParser::readNG_rmc()
{
    int counter = 0;
    char token[20];
    Tokeniser tok(buf, ',');

    while(tok.next(token, 20))
    {
        switch(counter)
        {
            case 1: //time
            {
                float time = atof(token);
                int hms = int(time);

                datetime.millis = time - hms;
                datetime.seconds = fmod(hms, 100);
                hms /= 100;
                datetime.minutes = fmod(hms, 100);
                hms /= 100;
                datetime.hours = hms;
                //  time_age = millis();
            }
            break;
            case 2:
            {
                if(token[0] == 'A')
                {
                    datetime.valid = true;
                    AINFO<<"GNRMC 定位有效";
                }
                
                if(token[0] == 'V')
                {
                    datetime.valid = false;
                    AINFO<<"GNRMC 定位无效";
                }
                    
            }
            break;
            case 3:
            {
                //ddmm.mmmm
                float llat = atof(token);

                int ilat = llat/100;
                double latmins = fmod(llat, 100);
                latitude = ilat + (latmins/60);
                
            }
            break;
            case 4:
            {
                if(token[0] == 'S')
                {
                    latitude = -latitude;
                    AINFO<<"南纬度="<<latitude;
                }
                else
                {
                    AINFO<<"北纬度="<<latitude;
                }
                ins_.mutable_position()->set_lat(latitude);
                // gnss_.mutable_position()->set_lon(latitude);
            }
            break;
            case 5:
            {
                float llong = atof(token);
                float ilat = llong/100;
                double lonmins = fmod(llong, 100);
                longitude = ilat + (lonmins/60);
            }
            break;
            case 6:
            {
                if(token[0] == 'W')
                {
                    longitude = -longitude;
                    AINFO<<"西经度="<<longitude;
                }
                else
                {
                    AINFO<<"东经度="<<longitude;
                }
                ins_.mutable_position()->set_lon(longitude);
                gnss_.mutable_position()->set_lon(longitude);

            }
            break;
            case 7:
            {
                // 字段 7：速度，节，Knots（一节也是1.852千米／小时）
                speed = atof(token);
                AINFO<<"地面速度="<<speed;
            }
            break;
            case 8:
            {
                //字段 8：方位角，度（二维方向指向，相当于二维罗盘）
                course = atof(token);
                AINFO<<"地面航向="<<course;
                double yaw = azimuth_deg_to_yaw_rad(course);
                gnss_.mutable_linear_velocity()->set_x(speed * cos(yaw));
                gnss_.mutable_linear_velocity()->set_y(speed * sin(yaw));
                gnss_.mutable_linear_velocity()->set_z(0);//垂直速度

                // course_age = millis();
            }
            break;
            case 9:
            {
                //ddmmyy  UTC日期:ddmmyy(日月年)格式 eg:020818
                uint32_t date = atoi(token);
                datetime.year = fmod(date, 100);
                date /= 100;
                datetime.month = fmod(date, 100);
                datetime.day = date / 100;

                AINFO<<oct<<datetime.year<<"年"<<oct<<datetime.month<<"月"<<oct<<datetime.day<<"日"<<oct<<datetime.hours<<":"<<oct<<datetime.minutes<<":"<<oct<<datetime.seconds;
                // date_age = millis(); hours, minutes, seconds
                // gnss_.mutable_header()->set_timestamp_sec(ros::Time::now().toSec());
                ins_.mutable_header()->set_timestamp_sec(ros::Time::now().toSec());
            }
            break;
            // 字段10：磁偏角，（000 - 180）度（前导位数不足则补0）
            //   字段11：磁偏角方向，E=东，W=西
        }
        counter++;
    }
}

void YuanShanParser::read_vtg()
{
    int counter = 0;
    char token[20];
    Tokeniser tok(buf, ',');

    while(tok.next(token, 20))
    {
        switch(counter)
        {
        case 1:
        {
            course = (atof(token)*100);
            // course_age = millis();
        }
        break;
        case 5:
        {
            knots = (atof(token)*100);
            // knots_age = millis();
        }
        break;
        case 7:
        {
            speed = (atof(token)*100);
            // speed_age = millis();
        }
        break;
        }
        counter++;
    }
}


bool YuanShanParser::check_checksum()
{
    uint8_t sum_check = 0,sum = 0;
    //[ $GNRMC,055136.00,A,3023.81376766,N,10404.32368675,E,0.035,71.4,020818,0.0,E,A*1F ]
    //代表了“$”和“*”之间所有字符的按位异或值
    if (buf[strlen(buf)-4] == '*')
    {
        //获取检验值
        sum = parse_hex(buf[strlen(buf)-3]) * 16;
        sum += parse_hex(buf[strlen(buf)-2]);
        //AINFO<<"sum 0="<<sum;//
        //AINFO<<"sum_check 0="<<hex<<sum_check<<"len ="<<(strlen(buf)-6);
        for (size_t i=0; i < (strlen(buf)-6); i++)
        {
            // AINFO <<i+2<<"="<<buf[i+2];
            sum_check ^= buf[i+2];
        }
        //  AINFO<<"sum_check 1="<<hex<<sum_check;
        if (sum != sum_check)
        {
            return false;
        }
            

        return true;
    }
    return false;
}


}  // namespace gnss
}  // namespace drivers
}  // namespace apollo